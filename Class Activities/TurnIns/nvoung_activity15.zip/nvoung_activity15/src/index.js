import React from "react";
import ReactDOM from "react-dom/client";
import Shop from './Shopping.js';


const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
<div>
<Shop />
</div>
);
