var express = require("express");
var cors = require("cors");
var fs = require("fs");
var bodyParser = require("body-parser");
var app = express();

app.use(cors());
app.use(bodyParser.json());

const port = "8081";
const host = "localhost";

const { MongoClient } = require("mongodb");
// MongoDB
const url = "mongodb://127.0.0.1:27017";
const dbName = "secoms3190";
const client = new MongoClient(url);

let db;

async function startServer() {
  await client.connect();
  db = client.db(dbName);
  console.log("Connected to MongoDB");

  app.listen(port, () => {
    console.log("App listening at http://%s:%s", host, port);
  });
}

startServer();

app.get("/listMovies", async (req, res) => {
  console.log("Node connected successfully to GET MongoDB");

  const query = {};
  const results = await db.collection("movie").find(query).limit(100).toArray();
  console.log(results);

  res.status(200).send(results);
});

app.get("/:id", async (req, res) => {
  const movieId = req.params.id;
  console.log("Movie to find :", movieId);

  const query = { movieId: movieId };
  const results = await db.collection("movie").findOne(query);
  console.log("Results :", results);

  if (!results) {
    res.status(404).json({ error: "Not Found" });
  } else {
    res.status(200).json(results);
  }
});
