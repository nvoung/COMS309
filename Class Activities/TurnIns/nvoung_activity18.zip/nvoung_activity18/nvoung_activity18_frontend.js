function fetchData() {
  // Read the DB with movies :
  fetch("http://localhost:8081/listMovies")
    .then((response) => response.json())
    .then((myMovies) => {
      console.log(myMovies);
      loadMovies(myMovies);
    })
    .catch((err) => console.log("error:" + err));
}

fetchData();

function loadMovies(myMovies) {
  console.log(myMovies);
  var CardMovie = document.getElementById("col");
  for (var i = 0; i < myMovies.length; i++) {
    let title = myMovies[i].title;
    let year = myMovies[i].year;
    let url = myMovies[i].url;
    let AddCardMovie = document.createElement("div");
    AddCardMovie.classList.add("col"); // Add Bootstrap class to the column
    AddCardMovie.innerHTML = `
      <div class="card shadow-sm">
      <img src=${url} class="card-img-top" alt="..."></img>
      <div class="card-body">
      <p class="card-text"> <strong>${title}</strong>, ${year}</p>
      </div>
      </div>
      `;
    CardMovie.appendChild(AddCardMovie);
  } // end of for
} // end of function

function showOneMovie() {
  let id = document.getElementById("movieId").value;
  fetch(`http://localhost:8081/${id}`)
  .then(response => {
      if (!response.ok) {
          throw new Error("Network response was not ok " + response.statusText);
      }
      return response.json();
  })
  .then(myFavoriteMovie => loadOneMovie(myFavoriteMovie))
  .catch(err => console.error("Error fetching movie:", err));
}

function loadOneMovie(myFavoriteMovie) {
  console.log(myFavoriteMovie);

  var CardMovie = document.getElementById("col"); // The container where the card will be added
  CardMovie.innerHTML = ""; // Clear any previous content

  let title = myFavoriteMovie.title;
  let year = myFavoriteMovie.year;
  let url = myFavoriteMovie.url || "path/to/default-image.jpg"; // Use a default image if the URL is missing

  let AddCardMovie = document.createElement("div");
  AddCardMovie.classList.add("col"); // Add Bootstrap column class
  AddCardMovie.innerHTML = `
    <div class="card shadow-sm">
      <img src="${url}" class="card-img-top" alt="${title}">
      <div class="card-body">
        <p class="card-text"><strong>${title}</strong>, ${year}</p>
      </div>
    </div>
  `;

  CardMovie.appendChild(AddCardMovie); // Append the card to the container
}

