import React from 'react';
import ReactDOM from 'react-dom/client';
import App from "./MyApplication.js"
import Payment from './MyPayment.js';
import Summary from './MySummary.js';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

