This is the Repository for Nathan Voung and Doyle Chism's work on our COMS3190 midterm project. 
